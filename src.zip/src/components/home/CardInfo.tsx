"use client";

import { useState, useEffect } from "react";
import { MapPin } from "lucide-react";
import { DummyRegion } from "@/lib/mock-data";

interface CardInfoProps {
  region: any;
  onDetail?: () => void;
}

const normalize = (value: string) =>
  value.trim().toLowerCase();

const findUserRegion = (
  lat: number,
  lng: number,
  dummyRegions: DummyRegion[]
): DummyRegion | undefined => {
  let closestRegion: DummyRegion | undefined;
  let minDistance = Infinity;

  for (const region of dummyRegions) {
    const distance = Math.sqrt(
      Math.pow(lat - region.latitude, 2) + Math.pow(lng - region.longitude, 2)
    );
    if (distance < minDistance) {
      minDistance = distance;
      closestRegion = region;
    }
  }

  if (minDistance < 0.05) {
    return closestRegion;
  }

  return undefined;
};

export function CardInfo({ region, onDetail }: CardInfoProps) {
  if (!region) {
    return (
      <div className="py-12 px-6 text-center">
        Data wilayah belum tersedia
      </div>
    );
  }

  const riskColors: Record<string, string> = {
    AMAN: "#22c55e",
    WASPADA: "#eab308",
    SIAGA: "#ef4444",
  };

  const riskIcons: Record<string, string> = {
    AMAN: "check-circle",
    WASPADA: "alert-circle",
    SIAGA: "alert-octagon",
  };

  const riskDescs: Record<string, string> = {
    AMAN: "Risiko terendara",
    WASPADA: "Risiko sanitasi air perlu diperhatikan",
    SIAGA: "Risiko tinggi, tindakan segera",
  };

  return (
    <div className="py-12 px-6 max-w-3xl mx-auto">
      <div className="border rounded-2xl border-border bg-white dark:bg-black p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <MapPin className="size-4 text-primary" />
            <span className="text-sm font-medium text-primary">Wilayah Anda</span>
          </div>

          <button onClick={onDetail} className="rounded-lg bg-primary px-3 py-1.5 text-sm font-medium text-primary-foreground hover:bg-primary/90 transition-colors">
            Lihat Detail
          </button>
        </div>

        <h2 className="text-xl font-bold text-primary mb-1">{region.name}</h2>
        <p className="text-base text-muted-foreground">{region.city}</p>

        <div className="mt-4 flex items-center gap-2">
          <span
            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-sm font-medium"
            style={{ backgroundColor: riskColors[region.status], color: riskColors[region.status] === "#ef4444" ? "#fff" : "#111827" }}
          >
            <span className="size-3.5" style={{ color: riskColors[region.status] }}>
              {riskIcons[region.status]}
            </span>
            {region.status}
          </span>
          <span className="text-sm text-muted-foreground">
            {riskDescs[region.status]}
          </span>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-4 md:grid-cols-4">
          <div>
            <p className="text-xs font-medium text-muted-foreground">Status IPA</p>
            <p className="mt-1">{region.ipaStatus === "MATI" ? "MATI" : "AKTIF"}</p>
          </div>
          <div>
            <p className="text-xs font-medium text-muted-foreground">Laporan 24 Jam</p>
            <p className="mt-1">{region.symptomReports != null ? region.symptomReports : "Belum tersedia"} laporan</p>
          </div>
        </div>

        <p className="mt-4 text-sm text-muted-foreground">
          {region.ipaCondition ? "Gangguan operasional: " + region.ipaCondition : "Operasional normal"}
        </p>

        <p className="mt-4 text-sm text-muted-foreground">
          Diperbarui {region.lastUpdated || "sedang"} lalu
        </p>

        <div className="mt-6">
          <button onClick={onDetail} className="w-full rounded-lg bg-primary px-4 py-2 text-lg font-bold text-primary-foreground hover:bg-primary/90 transition-colors">
            Lihat Detail Wilayah
          </button>
        </div>
      </div>
    </div>
  );
}