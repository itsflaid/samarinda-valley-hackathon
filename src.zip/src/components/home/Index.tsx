"use client";

import { useState, useEffect } from "react";
import { Hero } from "@/components/home/Hero";
import { CardInfo } from "@/components/home/CardInfo";

export function HomeContent() {
  const [userCoords, setUserCoords] = useState<{ lat: number; lng: number } | undefined>();

  return (
    <main>
      <Hero onLocate={(lat, lng) => setUserCoords({ lat, lng })} />
    </main>
  );
}