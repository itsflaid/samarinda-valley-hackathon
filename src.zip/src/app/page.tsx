import { Hero } from "@/components/home/Hero";
import { RegionMap } from "@/components/home/Map";
import { CardInfo } from "@/components/home/CardInfo";

export default function Home() {
  const defaultRegion = {
    id: "samarinda-samarinda-ilir",
    name: "Samarinda Ilir",
    city: "Samarinda",
    province: "Kalimantan Timur",
    status: "AMAN",
    ipaStatus: "AKTIF",
    ipaCondition: "Operasional normal",
    symptomReports: 2,
    lastUpdated: "10 menit lalu",
    latitude: -0.493,
    longitude: 117.161,
  };

  return (
    <main>
      <Hero />
      <RegionMap />
      <CardInfo region={defaultRegion} />
    </main>
  );
}